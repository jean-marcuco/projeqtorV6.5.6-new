
-- ///////////////////////////////////////////////////////////
-- // PROJECTOR EXPORT                                      //
-- //-------------------------------------------------------//
-- // Version : V0.1.0                                      //
-- // Date : 2009-06-03                                     //
-- ///////////////////////////////////////////////////////////

-- -----------------------------------------------------------
-- Database is expedted to exist. If not, these lines may help
-- -----------------------------------------------------------
--SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
--CREATE DATABASE ${database} DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
--USE ${database};
-- --------------------------------------------------------

-- No more action.
-- V0.3.0 is expecting an empty database 